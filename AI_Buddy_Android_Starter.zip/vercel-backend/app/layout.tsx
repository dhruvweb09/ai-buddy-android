import type { Metadata } from "next";
export const metadata: Metadata = { title: "AI Buddy API", description: "AI Buddy backend" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
