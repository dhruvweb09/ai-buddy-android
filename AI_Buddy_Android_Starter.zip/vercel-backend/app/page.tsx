export default function Home() {
  return <main style={{fontFamily:"system-ui",padding:32}}>
    <h1>AI Buddy backend</h1>
    <p>API is deployed. Connect the Android app using the deployment URL.</p>
    <p>Endpoints: <code>/api/chat</code> and <code>/api/vision</code>.</p>
  </main>;
}
