import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const { message, history = [] } = await req.json();
    if (typeof message !== "string" || !message.trim() || message.length > 12000) {
      return NextResponse.json({ error: "Provide a message up to 12,000 characters." }, { status: 400 });
    }
    const key = process.env.AI_GATEWAY_API_KEY;
    if (!key) return NextResponse.json({ error: "Backend AI Gateway key is not configured." }, { status: 503 });

    const safeHistory = Array.isArray(history)
      ? history.slice(-12).filter((m: any) =>
          m && ["user", "assistant"].includes(m.role) && typeof m.content === "string"
        ).map((m: any) => ({ role: m.role, content: m.content.slice(0, 4000) }))
      : [];

    const upstream = await fetch("https://ai-gateway.vercel.sh/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json", "x-title": "AI Buddy Android" },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "openai/gpt-5.6",
        messages: [
          { role: "system", content: "You are AI Buddy, a concise, friendly, respectful assistant. Help with everyday questions and study. Do not claim to control the phone unless a supported action has actually been performed." },
          ...safeHistory,
          { role: "user", content: message }
        ],
        stream: false,
        max_tokens: 900
      }),
      signal: AbortSignal.timeout(45000)
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return NextResponse.json({ error: "AI provider request failed.", detail: data?.error?.message || upstream.statusText }, { status: 502 });
    const answer = data?.choices?.[0]?.message?.content;
    if (typeof answer !== "string") return NextResponse.json({ error: "The AI returned no text response." }, { status: 502 });
    return NextResponse.json({ answer });
  } catch {
    return NextResponse.json({ error: "Request failed or timed out." }, { status: 500 });
  }
}
