import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const { imageBase64, prompt = "Describe the visible screen and help with the user's question." } = await req.json();
    if (typeof imageBase64 !== "string" || imageBase64.length > 8_000_000) {
      return NextResponse.json({ error: "A valid imageBase64 payload under 8 MB is required." }, { status: 400 });
    }
    const key = process.env.AI_GATEWAY_API_KEY;
    if (!key) return NextResponse.json({ error: "Backend AI Gateway key is not configured." }, { status: 503 });
    const imageUrl = imageBase64.startsWith("data:image/")
      ? imageBase64
      : `data:image/jpeg;base64,${imageBase64}`;
    const upstream = await fetch("https://ai-gateway.vercel.sh/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json", "x-title": "AI Buddy Android" },
      body: JSON.stringify({
        model: process.env.AI_VISION_MODEL || "openai/gpt-5.6",
        messages: [{ role: "user", content: [
          { type: "text", text: String(prompt).slice(0, 3000) },
          { type: "image_url", image_url: { url: imageUrl } }
        ] }],
        max_tokens: 1000,
        stream: false
      }),
      signal: AbortSignal.timeout(55000)
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return NextResponse.json({ error: "Vision request failed.", detail: data?.error?.message || upstream.statusText }, { status: 502 });
    const answer = data?.choices?.[0]?.message?.content;
    if (typeof answer !== "string") return NextResponse.json({ error: "The AI returned no image analysis." }, { status: 502 });
    return NextResponse.json({ answer });
  } catch {
    return NextResponse.json({ error: "Vision request failed or timed out." }, { status: 500 });
  }
}
