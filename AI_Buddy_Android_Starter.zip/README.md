# AI Buddy — Android + Vercel starter

This starter contains:
- Native Android app (Kotlin): floating overlay bubble, explicit MediaProjection screen capture, screenshot upload to a Vercel API, and text chat UI.
- Vercel Next.js backend: `/api/chat` text chat and `/api/vision` image understanding via Vercel AI Gateway.

## Important status
This is source code, **not a compiled APK**. Build the APK with Android Studio (or CI) after configuring the backend. Android overlay and screen capture permissions are deliberately user-controlled. Screen images are sent to your backend only after you press Capture and confirm the Android screen-sharing prompt.

## 1. Configure Vercel backend
1. Import the `vercel-backend` directory as a new Vercel project.
2. Set `AI_GATEWAY_API_KEY` in Project Settings → Environment Variables. Use a Vercel AI Gateway key; do not put it in Android source.
3. Deploy and copy the deployment URL.
4. Set `API_BASE_URL` in `android/app/build.gradle.kts` to `https://YOUR-PROJECT.vercel.app/`.

The backend uses the OpenAI-compatible Vercel AI Gateway endpoint. Change `AI_MODEL` in Vercel environment variables if you prefer another model supported by your account. Default: `openai/gpt-5.6`.

## 2. Build APK
1. Install Android Studio and Android SDK.
2. Open the `android` folder in Android Studio.
3. Set `API_BASE_URL` in `app/build.gradle.kts`.
4. Sync Gradle, then Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Install the generated debug APK from `android/app/build/outputs/apk/debug/app-debug.apk`.

## Included capabilities
- Overlay companion bubble (drag to move, tap to open app).
- User-triggered screen capture using Android MediaProjection consent UI.
- Sends one captured frame to `/api/vision` for analysis.
- Text chat against `/api/chat`.

## Not included yet
- Always-on background listening (intentionally excluded).
- True real-time continuous screen streaming.
- Spoken AI output / speech recognition, persistent chat storage, Play Store signing, and advanced actions. These should be added after the basic APK builds and the backend is tested.
- Arbitrary control of other apps. Android limits accessibility and cross-app automation; any such feature should be explicit, permissioned, and limited.

## Security notes
- Never ship a Vercel API key in the APK.
- Add authentication, per-user rate limits, request size limits, and privacy disclosures before public release.
- Screen contents may contain sensitive information; capture only when you intend to share it.
