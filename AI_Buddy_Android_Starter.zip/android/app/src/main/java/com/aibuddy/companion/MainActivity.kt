package com.aibuddy.companion

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private val history = JSONArray()

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val svc = Intent(this, FloatingCompanionService::class.java).apply {
                action = FloatingCompanionService.ACTION_CAPTURE
                putExtra(FloatingCompanionService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(FloatingCompanionService.EXTRA_RESULT_DATA, result.data)
            }
            startService(svc)
            addLine("AI Buddy", "Screen sharing was approved. Use the floating bubble's Capture action to analyze a frame.")
        } else addLine("AI Buddy", "Screen sharing cancelled.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 18)
            setBackgroundColor(0xFF101827.toInt())
        }
        val title = TextView(this).apply {
            text = "AI Buddy"; textSize = 28f; setTextColor(0xFFFFFFFF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Your screen companion"; textSize = 14f; setTextColor(0xFF9CB2D0.toInt())
        }
        transcript = TextView(this).apply {
            text = "AI Buddy: Hi! Ask me a question, or enable the floating companion.\\n\\n"
            textSize = 16f; setTextColor(0xFFE8EEF8.toInt()); setPadding(4, 12, 4, 12)
        }
        val scroll = ScrollView(this).apply { addView(transcript) }
        input = EditText(this).apply {
            hint = "Ask AI Buddy…"; setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9CB2D0.toInt())
        }
        val send = Button(this).apply { text = "Send question"; setOnClickListener { sendChat() } }
        val float = Button(this).apply { text = "Enable floating buddy"; setOnClickListener { enableFloating() } }
        val screen = Button(this).apply { text = "Share screen for analysis"; setOnClickListener { requestScreenShare() } }
        val privacy = TextView(this).apply {
            text = "Screen capture starts only after Android's system consent prompt. Captured frames are sent to your configured AI backend when you request analysis."
            textSize = 12f; setTextColor(0xFF9CB2D0.toInt()); setPadding(0, 10, 0, 4)
        }
        outer.addView(title); outer.addView(subtitle)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        outer.addView(input); outer.addView(send); outer.addView(float); outer.addView(screen); outer.addView(privacy)
        setContentView(outer)
    }

    private fun addLine(who: String, text: String) {
        runOnUiThread { transcript.append("$who: $text\\n\\n") }
    }

    private fun sendChat() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        input.setText("")
        addLine("You", message)
        io.execute {
            try {
                val body = JSONObject().put("message", message).put("history", history)
                val response = postJson("api/chat", body)
                val answer = response.optString("answer", response.optString("error", "No response"))
                history.put(JSONObject().put("role", "user").put("content", message))
                history.put(JSONObject().put("role", "assistant").put("content", answer))
                addLine("AI Buddy", answer)
            } catch (e: Exception) { addLine("AI Buddy", "Connection error: ${e.message ?: "unknown error"}") }
        }
    }

    private fun enableFloating() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Allow display over other apps, then return here.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, FloatingCompanionService::class.java).apply {
            action = FloatingCompanionService.ACTION_SHOW
        })
    }

    private fun requestScreenShare() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun postJson(path: String, body: JSONObject): JSONObject {
        val base = BuildConfig.API_BASE_URL
        require(base.startsWith("https://") && !base.contains("YOUR-PROJECT")) {
            "Set API_BASE_URL in app/build.gradle.kts to your deployed HTTPS Vercel URL"
        }
        val conn = (URL(base.trimEnd('/') + "/" + path).openConnection() as HttpURLConnection)
        conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        val json = JSONObject(text)
        if (json.has("error") && !json.has("answer")) throw IllegalStateException(json.optString("error"))
        return json
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }
}
