package com.aibuddy.companion

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class FloatingCompanionService : Service() {
    companion object {
        const val ACTION_SHOW = "com.aibuddy.SHOW"
        const val ACTION_CAPTURE = "com.aibuddy.CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private val io = Executors.newSingleThreadExecutor()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showBubble()
            ACTION_CAPTURE -> {
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                if (data != null) startProjection(code, data)
            }
        }
        return START_NOT_STICKY
    }

    private fun showBubble() {
        if (bubble != null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = "AI"; textSize = 17f; gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xFF5B5FEF.toInt())
            elevation = 12f
        }
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(62, 62, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 30; y = 240
        }
        view.setOnTouchListener(object : android.view.View.OnTouchListener {
            var startX = 0; var startY = 0; var downX = 0f; var downY = 0f
            var moved = false
            override fun onTouch(v: android.view.View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; downX = e.rawX; downY = e.rawY; moved = false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) > 5 || kotlin.math.abs(dy) > 5) moved = true
                        params.x = startX + dx; params.y = startY + dy
                        wm.updateViewLayout(view, params); return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) showActions()
                        return true
                    }
                }
                return false
            }
        })
        wm.addView(view, params)
        bubble = view
    }

    private fun showActions() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 12, 18, 12)
            setBackgroundColor(0xFF172033.toInt())
        }
        val header = TextView(this).apply { text = "AI Buddy"; textSize = 20f; setTextColor(-1) }
        val open = Button(this).apply { text = "Open chat"; setOnClickListener {
            val launch = packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (launch != null) startActivity(launch)
        } }
        val capture = Button(this).apply { text = "Analyze shared screen"; setOnClickListener {
            captureFrame(); Toast.makeText(this@FloatingCompanionService, "Analyzing a captured frame…", Toast.LENGTH_SHORT).show()
        } }
        val close = Button(this).apply { text = "Close bubble"; setOnClickListener { bubble?.let { wm.removeView(it) }; bubble = null } }
        panel.addView(header); panel.addView(open); panel.addView(capture); panel.addView(close)
        android.app.AlertDialog.Builder(android.view.ContextThemeWrapper(this, android.R.style.Theme_Material_Light_Dialog_Alert))
            .setView(panel).setNegativeButton("Done", null).show().window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
    }

    private fun startProjection(code: Int, data: Intent) {
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            val metrics = resources.displayMetrics
            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            virtualDisplay = projection?.createVirtualDisplay(
                "AIBuddyScreen", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start screen capture: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun captureFrame() {
        val r = reader
        if (r == null) {
            Toast.makeText(this, "First tap Share screen for analysis in the app and approve Android's prompt.", Toast.LENGTH_LONG).show()
            return
        }
        io.execute {
            try {
                Thread.sleep(250)
                val image = r.acquireLatestImage() ?: throw IllegalStateException("No frame available yet")
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * image.width
                val full = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(buffer)
                image.close()
                val cropped = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
                val scaled = Bitmap.createScaledBitmap(cropped, minOf(1000, cropped.width), (cropped.height * minOf(1000f / cropped.width, 1000f / cropped.height)).toInt().coerceAtLeast(1), true)
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 70, out)
                val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                val base = BuildConfig.API_BASE_URL.trimEnd('/')
                val response = (java.net.URL("$base/api/vision").openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                response.outputStream.use { it.write(JSONObject().put("imageBase64", b64).put("prompt", "Explain what is visible on my phone screen and point out anything useful. Be careful not to expose sensitive information unnecessarily.").toString().toByteArray()) }
                val stream = if (response.responseCode in 200..299) response.inputStream else response.errorStream
                val json = JSONObject(stream.bufferedReader().use { it.readText() })
                val answer = json.optString("answer", json.optString("error", "No response"))
                val launch = packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
                Toast.makeText(this, answer.take(180), Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Screen analysis failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        try { virtualDisplay?.release(); reader?.close(); projection?.stop() } catch (_: Exception) {}
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        io.shutdownNow()
        super.onDestroy()
    }
}
