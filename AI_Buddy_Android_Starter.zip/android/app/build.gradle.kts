plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.aibuddy.companion"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aibuddy.companion"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        // Replace with your deployed Vercel URL, including trailing slash.
        buildConfigField("String", "API_BASE_URL", "\"https://YOUR-PROJECT.vercel.app/\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
